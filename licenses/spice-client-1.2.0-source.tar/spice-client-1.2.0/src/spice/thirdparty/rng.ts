// Downloaded from http://www-cs-students.stanford.edu/~tjw/jsbn/ by Jeremy White on 6/1/2012

/*
 * Copyright (c) 2003-2005  Tom Wu
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT SHALL TOM WU BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
 * INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES WHATSOEVER
 * RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT ADVISED OF
 * THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY, ARISING OUT
 * OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * In addition, the following condition applies:
 *
 * All redistributions must retain an intact copy of this copyright notice
 * and disclaimer.
 */

// Random number generator - requires a PRNG backend, e.g. prng4.js
import { prng_newstate, rng_psize } from './prng4.js'

// For best results, put code like
// <body onClick='rng_seed_time();' onKeyPress='rng_seed_time();'>
// in your main HTML document.

let rng_state: any
let rng_pool: number[]
let rng_pptr: number

// Mix in a 32-bit integer into the pool
function rng_seed_int (x: number) {
  rng_pool[rng_pptr++] ^= x & 255
  rng_pool[rng_pptr++] ^= (x >> 8) & 255
  rng_pool[rng_pptr++] ^= (x >> 16) & 255
  rng_pool[rng_pptr++] ^= (x >> 24) & 255
  if (rng_pptr >= rng_psize) rng_pptr -= rng_psize
}

// Mix in the current time (w/milliseconds) into the pool
function rng_seed_time () {
  rng_seed_int(new Date().getTime())
}

// Initialize the pool with junk if needed.
if (rng_pool == null) {
  rng_pool = []
  rng_pptr = 0
  let t: number
  if (navigator.appName == 'Netscape' && navigator.appVersion < '5' && (window as any).crypto) {
    // Extract entropy (256 bits) from NS4 RNG if available
    const z = (window as any).crypto.random(32)
    for (t = 0; t < z.length; ++t) { rng_pool[rng_pptr++] = z.charCodeAt(t) & 255 }
  }
  while (rng_pptr < rng_psize) { // extract some randomness from Math.random()
    t = Math.floor(65536 * Math.random())
    rng_pool[rng_pptr++] = t >>> 8
    rng_pool[rng_pptr++] = t & 255
  }
  rng_pptr = 0
  rng_seed_time()
  // rng_seed_int(window.screenX);
  // rng_seed_int(window.screenY);
}

function rng_get_byte (): number {
  if (rng_state == null) {
    rng_seed_time()
    rng_state = prng_newstate()
    rng_state.init(rng_pool)
    for (rng_pptr = 0; rng_pptr < rng_pool.length; ++rng_pptr) { rng_pool[rng_pptr] = 0 }
    rng_pptr = 0
    // rng_pool = null;
  }
  // TODO: allow reseeding after first request
  return rng_state.next()
}

function rng_get_bytes (ba: number[]) {
  let i: number
  for (i = 0; i < ba.length; ++i) ba[i] = rng_get_byte()
}

export class SecureRandom {
  nextBytes (ba: number[]) {
    rng_get_bytes(ba)
  }
}
